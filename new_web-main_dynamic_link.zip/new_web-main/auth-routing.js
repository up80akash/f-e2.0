// Single source of truth for "which URL does each role belong to" -- every
// login form, every dashboard's logout button, and every session-guard
// (requireRole in dashboard-common.js) reads from this instead of
// hardcoding a URL of its own. This is what fixes two related bugs:
//   1. Logging out (or an expired/invalid session) from ANY dashboard used
//      to always redirect to admin-login.html, regardless of which role
//      was actually logged out -- a normal user landed on the admin login
//      screen. Each role now goes back to ITS OWN login page.
//   2. Clicking the site logo just links to login.html; an already-
//      authenticated visitor showed a login form instead of their app,
//      which read like they'd been logged out even though their session
//      (the fe_token in localStorage) was never touched. login.html and
//      admin-login.html now check for an existing valid session on load
//      and immediately hand the visitor back to their own landing page --
//      no session is ever cleared by navigation, only by an explicit
//      logout click.
const ROLE_LANDING_PAGE = {
  admin: "admin-dashboard.html",
  subadmin: "subadmin-dashboard.html",
  // Games are the primary user-facing landing experience (see
  // user-dashboard.html's default-active tab) -- sending users straight to
  // the #/games route keeps this explicit even if that default ever
  // changes independently.
  user: "user-dashboard.html#/games",
};

const ROLE_LOGIN_PAGE = {
  admin: "admin-login.html",
  subadmin: "admin-login.html",
  user: "login.html",
};

function landingPageForRole(role) {
  return ROLE_LANDING_PAGE[role] || "login.html";
}

function loginPageForRole(role) {
  return ROLE_LOGIN_PAGE[role] || "login.html";
}

// Called on load by login.html and admin-login.html. If a valid-looking
// session already exists, skip the login form entirely and go straight to
// that role's landing page -- this never modifies localStorage, it only
// reads it, so an existing session is always left completely intact.
function redirectIfAlreadyAuthenticated() {
  const token = localStorage.getItem("fe_token");
  const role = localStorage.getItem("fe_role");
  if (token && role) {
    window.location.replace(landingPageForRole(role));
  }
}
